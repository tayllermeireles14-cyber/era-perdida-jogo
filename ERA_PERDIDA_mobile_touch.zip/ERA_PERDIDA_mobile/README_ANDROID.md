# ERA PERDIDA — Mobile

Base C++/raylib com:
- joystick virtual
- ataque
- poção
- interação
- coleta
- inventário touchscreen
- 6 biomas de superfície
- 4 biomas subterrâneos
- combate, XP, níveis, ouro e chefe

## Importante
Este arquivo é o código-fonte. Ele não é um APK já compilado.

Para gerar APK Android:
1. Instale Android Studio.
2. Instale Android SDK, NDK e CMake.
3. Configure uma build de raylib para Android.
4. Coloque `src/main.cpp` no projeto.
5. Gere com Gradle/Android Studio.

A base já usa raylib e foi escrita sem dependências externas de assets, facilitando o primeiro build.
