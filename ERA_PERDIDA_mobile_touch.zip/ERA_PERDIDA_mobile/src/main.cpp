#include "raylib.h"
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>

enum class Biome { Forest, Desert, Frozen, Flowers, Volcano, Coast, Mines, Mushrooms, Crystals, Crypt };

struct BI {
    const char* name; Color ground, accent; bool underground;
};
static const BI B[]={
 {"Floresta Aurora",{62,125,65,255},{90,190,90,255},false},
 {"Deserto Escarlate",{190,120,55,255},{220,75,45,255},false},
 {"Montanhas Gelidas",{170,205,220,255},{245,250,255,255},false},
 {"Vale das Flores",{105,155,85,255},{245,120,190,255},false},
 {"Terras Vulcanicas",{80,48,42,255},{240,75,25,255},false},
 {"Costa Perdida",{45,125,150,255},{80,205,225,255},false},
 {"Minas Antigas",{45,43,50,255},{180,135,75,255},true},
 {"Abismo dos Cogumelos",{55,35,70,255},{205,75,210,255},true},
 {"Cavernas Cristalinas",{35,50,75,255},{80,210,255,255},true},
 {"Cripta da Era Perdida",{32,30,35,255},{190,65,85,255},true}
};

struct Player{Vector3 p{0,1,0};float hp=100,maxhp=100,sta=100,atkCD=0;int lvl=1,xp=0,gold=25,potions=3,wood=0,ore=0,crystals=0;int attack=12;};
struct Enemy{Vector3 p;float hp,maxhp,speed;int dmg;bool boss=false,alive=true;};

float d2(Vector3 a,Vector3 b){return sqrtf((a.x-b.x)*(a.x-b.x)+(a.z-b.z)*(a.z-b.z));}

Biome biomeAt(Vector3 p,bool under){
 if(under){int x=std::clamp((int)floor((p.x+90)/45),0,3);return (Biome)((int)Biome::Mines+x);}
 int c=std::clamp((int)floor((p.x+67.5f)/45),0,2),r=std::clamp((int)floor((p.z+45)/45),0,1);
 static Biome g[2][3]={{Biome::Forest,Biome::Desert,Biome::Frozen},{Biome::Flowers,Biome::Volcano,Biome::Coast}};
 return g[r][c];
}

void spawn(std::vector<Enemy>& es,Biome b){
 es.clear();int n=b==Biome::Crypt?7:5;
 for(int i=0;i<n;i++){Enemy e;e.p={-12+i*5.0f,1,(i%2?8:-8)};e.maxhp=e.hp=25+(int)b*5;e.dmg=4+(int)b;e.speed=.8f+(int)b*.04f;es.push_back(e);}
 if(b==Biome::Crypt){Enemy e;e.p={18,1,0};e.maxhp=e.hp=650;e.dmg=18;e.speed=.65f;e.boss=true;es.push_back(e);}
}

void tree(Vector3 p){DrawCylinder({p.x,1.3f,p.z},.35f,.35f,2.6f,6,BROWN);DrawSphere({p.x,3,p.z},1.15f,DARKGREEN);}
void crystal(Vector3 p,Color c){DrawCylinder({p.x,1.1f,p.z},.22f,.05f,2.2f,5,c);}

void world(Biome b,bool under){
 DrawPlane({0,0,0},{270,150},B[(int)b].ground);
 for(int x=-120;x<=120;x+=15)for(int z=-60;z<=60;z+=15){
  unsigned h=(unsigned)((x+200)*928371u^(z+500)*689287u); if(h%100>=14)continue;
  Vector3 p={(float)x,0,(float)z};
  if(b==Biome::Forest)tree(p);
  else if(b==Biome::Flowers){DrawCylinder({p.x,.2f,p.z},.2f,.2f,.3f,6,B[(int)b].accent);}
  else if(b==Biome::Mines||b==Biome::Crystals)crystal(p,B[(int)b].accent);
  else DrawCube({p.x,.5f,p.z},1,1,1,B[(int)b].accent);
 }
 if(under)for(int x=-120;x<=120;x+=18)for(int z=-60;z<=60;z+=18)DrawCube({(float)x,7,(float)z},12,1,12,Fade(DARKGRAY,.65f));
}

bool circleButton(Vector2 c,float r,const char* txt){
 bool down=IsMouseButtonDown(MOUSE_BUTTON_LEFT)||IsMouseButtonDown(MOUSE_BUTTON_RIGHT);
 Vector2 m=GetMousePosition(); bool hit=CheckCollisionPointCircle(m,c,r);
 DrawCircleV(c,r,Fade(BLACK,.60f));DrawCircleLines((int)c.x,(int)c.y,(int)r,Fade(RAYWHITE,.75f));
 int fs=(int)(r*.42f);DrawText(txt,(int)(c.x-MeasureText(txt,fs)/2),(int)(c.y-fs/2),fs,RAYWHITE);
 return hit&&down;
}

Vector2 joystick(Vector2 center,float radius){
 Vector2 m=GetMousePosition();bool active=IsMouseButtonDown(MOUSE_BUTTON_LEFT)&&CheckCollisionPointCircle(m,center,radius);
 Vector2 v={0,0};
 if(active){v={m.x-center.x,m.y-center.y};float l=sqrtf(v.x*v.x+v.y*v.y);if(l>radius){v.x*=radius/l;v.y*=radius/l;}DrawCircleV({center.x+v.x,center.y+v.y},radius*.42f,Fade(RAYWHITE,.8f));}
 else DrawCircleV(center,radius*.42f,Fade(RAYWHITE,.45f));
 DrawCircleLines((int)center.x,(int)center.y,radius,Fade(RAYWHITE,.6f));
 return {v.x/radius,v.y/radius};
}

int main(){
 const int W=1280,H=720;InitWindow(W,H,"ERA PERDIDA");SetTargetFPS(60);
 Camera3D cam{};cam.up={0,1,0};cam.fovy=55;cam.projection=CAMERA_PERSPECTIVE;
 Player pl;bool under=false,inv=false;Biome bio=Biome::Forest;std::vector<Enemy> es;spawn(es,bio);
 std::string msg="Explore a Era Perdida!";
 while(!WindowShouldClose()){
  float dt=GetFrameTime();
  Vector2 joy=joystick({105,590},75);
  Vector3 mv={joy.x,0,joy.y};
  if(IsKeyDown(KEY_W))mv.z-=1;if(IsKeyDown(KEY_S))mv.z+=1;if(IsKeyDown(KEY_A))mv.x-=1;if(IsKeyDown(KEY_D))mv.x+=1;
  float l=sqrtf(mv.x*mv.x+mv.z*mv.z);
  bool sprint=IsKeyDown(KEY_LEFT_SHIFT)&&pl.sta>1;
  if(l>1){mv.x/=l;mv.z/=l;}
  float speed=sprint?8:4.5f;
  pl.p.x+=mv.x*speed*dt;pl.p.z+=mv.z*speed*dt;
  pl.sta=sprint?std::max(0.f,pl.sta-25*dt):std::min(100.f,pl.sta+20*dt);
  pl.p.x=std::clamp(pl.p.x,-125.f,125.f);pl.p.z=std::clamp(pl.p.z,-70.f,70.f);

  Biome nb=biomeAt(pl.p,under);if(nb!=bio){bio=nb;spawn(es,bio);msg=B[(int)bio].name;}

  bool attack=circleButton({W-105.f,H-115.f},58,"ATQ");
  bool potion=circleButton({W-220.f,H-65.f},43,"PO");
  bool interact=circleButton({W-100.f,H-65.f},43,"E");
  bool collect=circleButton({W-315.f,H-65.f},43,"F");
  bool invbtn=circleButton({W-55.f,55},35,"I");

  if(IsKeyPressed(KEY_I)||invbtn)inv=!inv;
  pl.atkCD=std::max(0.f,pl.atkCD-dt);
  if((IsKeyPressed(KEY_SPACE)||attack)&&pl.atkCD<=0){pl.atkCD=.35f;for(auto &e:es)if(e.alive&&d2(pl.p,e.p)<4){e.hp-=pl.attack;msg=e.boss?"O Guardiao foi atingido!":"Inimigo atingido!";if(e.hp<=0){e.alive=false;pl.xp+=e.boss?500:35;pl.gold+=e.boss?500:10;}}}
  if((IsKeyPressed(KEY_Q)||potion)&&pl.potions>0&&pl.hp<pl.maxhp){pl.potions--;pl.hp=std::min(pl.maxhp,pl.hp+40);msg="Pocao usada!";}
  if((IsKeyPressed(KEY_F)||collect)){if(under){pl.ore++;pl.crystals++;msg="Minerio e cristal coletados!";}else{pl.wood++;msg="Madeira coletada!";}}
  if((IsKeyPressed(KEY_E)||interact)&&d2(pl.p,{0,1,0})<5){under=!under;pl.p={0,1,0};bio=biomeAt(pl.p,under);spawn(es,bio);msg=under?"Entrada subterranea!":"Voce voltou a superficie!";}

  for(auto&e:es)if(e.alive){float d=d2(pl.p,e.p);if(d<18){Vector3 q={pl.p.x-e.p.x,0,pl.p.z-e.p.z};float ll=sqrtf(q.x*q.x+q.z*q.z);if(ll>.1){e.p.x+=q.x/ll*e.speed*dt;e.p.z+=q.z/ll*e.speed*dt;}if(d<2)pl.hp-=e.dmg*dt;}}
  if(pl.hp<=0){pl.hp=pl.maxhp;pl.p={0,1,0};msg="Voce caiu em combate!";}
  if(pl.xp>=pl.lvl*100){pl.xp-=pl.lvl*100;pl.lvl++;pl.maxhp+=15;pl.hp=pl.maxhp;pl.attack+=3;msg="NOVO NIVEL!";}

  cam.target={pl.p.x,1,pl.p.z};cam.position={pl.p.x,9,pl.p.z+12};
  BeginDrawing();ClearBackground(under?Color{12,10,18,255}:SKYBLUE);BeginMode3D(cam);
  world(bio,under);
  for(auto&e:es)if(e.alive){Color c=e.boss?MAROON:RED;float s=e.boss?3:1.5f;DrawCube({e.p.x,1.1f,e.p.z},s,e.boss?3:2,s,c);}
  DrawCube({pl.p.x,1.1f,pl.p.z},1,2,1,BLUE);DrawCube({pl.p.x,2.45f,pl.p.z},.8,.8,.8,BEIGE);
  DrawCylinder({0,.8f,0},2.5,2.5,.4,24,under?GOLD:VIOLET);EndMode3D();

  DrawRectangle(15,15,330,105,Fade(BLACK,.65));DrawText("ERA PERDIDA",30,25,25,RAYWHITE);
  DrawText(TextFormat("Nivel %d | XP %d/%d",pl.lvl,pl.xp,pl.lvl*100),30,55,18,RAYWHITE);
  DrawRectangle(30,82,240,14,DARKGRAY);DrawRectangle(30,82,(int)(240*pl.hp/pl.maxhp),14,RED);
  DrawText(TextFormat("HP %.0f",pl.hp),280,79,16,RAYWHITE);
  DrawText(B[(int)bio].name,W/2-MeasureText(B[(int)bio].name,24)/2,22,24,B[(int)bio].accent);
  DrawText(msg.c_str(),20,H-28,18,YELLOW);
  DrawText("Joystic",45,675,14,GRAY);

  if(inv){DrawRectangle(280,125,720,430,Fade(BLACK,.94));DrawText("INVENTARIO",315,155,30,RAYWHITE);
   DrawText(TextFormat("Pocoes: %d",pl.potions),320,220,22,RAYWHITE);
   DrawText(TextFormat("Madeira: %d",pl.wood),320,260,22,RAYWHITE);
   DrawText(TextFormat("Minerio: %d",pl.ore),320,300,22,RAYWHITE);
   DrawText(TextFormat("Cristais: %d",pl.crystals),320,340,22,RAYWHITE);
   DrawText(TextFormat("Ouro: %d",pl.gold),320,380,22,GOLD);
  }
  EndDrawing();
 }
 CloseWindow();return 0;
}
